# Portfolio-Construction-and-Analysis
Portfolio Optimization and efficient frontier analysis
Here I will import prices datasets of some assets from different classes and then clean them for analysis. The goal is to use diversification to minimize the downside and maximize the upside, I will use modern portfolio theory for this. This is my first project of this type so it may not be a great one but yeah let's see.
